<?php
	mysql_connect("localhost","k5334818_oprec","opreccompfest") or die("Koneksi gagal");
	mysql_select_db("k5334818_submit");
?>