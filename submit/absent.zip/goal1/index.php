<?php
	header("location:https://docs.google.com/spreadsheet/viewform?formkey=dEZMTWFvT2hBek81X0FiZ0NCaVhSS0E6MQ");
?>